<?php if(!Auth::check()): ?>
    <script>window.location = "/";</script>
<?php endif; ?>


<?php $__env->startSection('title'); ?> Add Episode | <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container admin">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add Episode</div>
                <div class="card-body form-card">
                    <form method="POST" action="/add">
                        <?php echo csrf_field(); ?>

                        <div class="field">
                            <label class="label" for="episode-number">Episode Number:</label>
                            <div class="control">
                                <input class="input form-control" type="text" name="episode-number" id="episode-number">
                                <?php if($errors->has('episode-number')): ?>
                                    <p class="error-msg"><?php echo e($errors->first('episode-number')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="field">
                            <label class="label" for="title">Title:</label>
                            <div class="control">
                                <input class="input form-control" type="text" name="title" id="title">
                                <?php if($errors->has('title')): ?>
                                    <p class="error-msg"><?php echo e($errors->first('title')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="field">
                            <label class="label" for="link">Link:</label>
                            <div class="control">
                                <input class="input form-control" type="text" name="link" id="link">
                                <?php if($errors->has('link')): ?>
                                    <p class="error-msg"><?php echo e($errors->first('link')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="field">
                            <label class="label" for="jazz-fight">Jazz Fight:</label>
                            <div class="control">
                                <input class="input" type="checkbox" name="jazz-fight" id="jazz-fight">
                            </div>
                        </div>
                        <div class="field">
                            <label class="label" for="diamond-collection">Diamond Collection:</label>
                            <div class="control">
                                <input class="input" type="checkbox" name="diamond-collection" id="diamond-collection">
                            </div>
                        </div>
                        <div class="field">
                            <label class="label" for="published-date">Published Date:</label>
                            <div class="control">
                                <input class="input form-control" type="date" name="published-date" id="published-date">
                            </div>
                        </div>
                        <div class="field">
                            <label class="label" for="description">Description:</label>
                            <div class="control">
                                <textarea class="textarea form-control" name="description" id="description"></textarea>
                            </div>
                        </div>
                        <div class="field btns">
                            <button class="btn btn-lg submit" type="submit">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kings-speech-archive\resources\views/episodes/add.blade.php ENDPATH**/ ?>